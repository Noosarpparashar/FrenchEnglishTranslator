const expect = require('chai').expect;

it('This is kind of Dummy hello world test case', function () {
  const num1 = 2;
  const num2 = 2;
  expect(num1 + num2).to.equal(4);
});
