const express = require('express');
const axios = require('axios');
const log4js = require('log4js');
const token = require('../tokenFunction.js');

// axios.defaults.headers.common['Authorization']='Bearer '.concat(jsonContent.token)

log4js.configure({
  appenders: { fileAppender: { type: 'file', filename: 'output.log' } },
  categories: { default: { appenders: ['fileAppender'], level: 'info' } },
});

const logger = log4js.getLogger();

// const body = {};
// const config = {};

function routes() {
  const router = express.Router();
  router.route('/')
    .get(async (req, res) => {
      const accessToken = await token().then((resp) => resp.accessToken);

      const listClusters = await axios
        .get('https://capgeminietap.tmc.cloud.vmware.com/v1alpha/clustergroups',
          {
            headers: {
              Authorization: 'Bearer '.concat(accessToken),
            },
          }).then((resp) => {
          logger.info(resp.data);
          return resp.data;
        })
        .catch((error) => {
          logger.info(error.response);
          return error.response.data;
        });
      res.status(203).json({
        output: listClusters,
      });
    });
  return router;
}

module.exports = routes;
