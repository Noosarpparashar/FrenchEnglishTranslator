const express = require('express');
const axios = require('axios');
const fs = require('fs');

const token = require(__basedir + '/tokenFunction.js');

const parameters = fs.readFileSync('./routes/clusters/parameters.json');
const jsonContent = JSON.parse(parameters);

// axios.defaults.headers.common['Authorization']='Bearer '.concat(jsonContent.token)
const log4js = require('log4js');

log4js.configure({
  appenders: { fileAppender: { type: 'file', filename: 'output.log' } },
  categories: { default: { appenders: ['fileAppender'], level: 'info' } },
});

const logger = log4js.getLogger();

const body = jsonContent.bodyParameters;

//  const config = {};

function routes() {
  const router = express.Router();
  router.route('/')
    .get(async (req, res) => {
      const accessToken = await token().then((resp) => resp.accessToken);

      const createCluster = await axios
        .post('https://capgeminietap.tmc.cloud.vmware.com/v1alpha/clusters',
          body, {
            headers: {
              Authorization: 'Bearer '.concat(accessToken),
            },
          }).then((resp) => {
          logger.info(resp.data);
          return resp.data;
        })
        .catch((error) => {
          logger.error(error.response);
          return error.response.data;
        });
      res.status(203).json({
        output: createCluster,
      });
    });
  return router;
}

module.exports = routes;
