const express = require('express');

const app = express();
const port = process.env.PORT || 3004;
global.__basedir = __dirname;

const generateToken = require('./routes/generatetoken.js')();

app.use('/tanzu/generateToken', generateToken);
const createCluster = require('./routes/clusters/createCluster.js')();

app.use('/tanzu/createCluster', createCluster);
const listAttachedClusters = require('./routes/listAttachedClusters.js')();

app.use('/tanzu/listClusters', listAttachedClusters);

app.use((req, res) => {
  res.status(402);
  res.json({
    error: {
      message: 'Some unknown error..!!Probably above link doesnt exist',
    },
  });
});

app.listen(port, () => {
  console.log(`Running on port${port}`);
});
